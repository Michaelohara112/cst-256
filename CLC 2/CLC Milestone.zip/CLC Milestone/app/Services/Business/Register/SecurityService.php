<?php

namespace App\Services\Business\Register;

use App\Models\RegisterResponse;
use App\Services\Data\Register\SecurityDAO;

class SecurityService
{
    
    //validates register form request
    public function register($registerRequest) {
        
        //filters passed in variables
        $e = $this->filter($registerRequest->getEmail());
        $p = $this->filter($registerRequest->getPassword());
        $p2 = $this->filter($registerRequest->getPassword2());
        $f = $this->filter($registerRequest->getFirstName());
        $l = $this->filter($registerRequest->getLastName());
        
        //creates register response model instance
        $response = new RegisterResponse();
        $response->setSuccess(false);
        
        //creates security data service instance
        $securityDAO = new SecurityDAO();
        
            $registerRequest->setEmail($e);
            $registerRequest->setPassword($p);
            $registerRequest->setFirstName($f);
            $registerRequest->setLastName($l);
            
            //check if user with email already exists
            if (!$securityDAO->findEmail($registerRequest)) {
                
                //check if user was inserted correctly
                if ($securityDAO->createUser($registerRequest) > 0) {
                    $response->setSuccess(true);
                } else {
                    $response->setMsg("Error inserting user into database.");
                }
            } else {
                $response->setMsg("User with email already exists.");
            }
        
        return $response;
        
    }
    //filters strings
    function filter($str) {
        $str = trim($str);
        $str = stripslashes($str);
        $str = htmlspecialchars($str);
        return $str;
    }    
    //checks if string is valid email
    function isEmail($str) {
        return filter_var($str, FILTER_VALIDATE_EMAIL);
    }
    
}

