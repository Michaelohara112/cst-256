@extends('layouts.app')
@section('title', 'Register Page')
@section('content')

<html>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Register') }}</div>

                <div class="card-body">
<form action="doRegister" method="POST">
	<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
		@if(isset($error))
    		<div style="color: red">
        		Error: {{ $error }} <br>
        		<br>
        	</div>
    	@endif	
	<table>
		<tr>
			<td>Email Address:</td>
			<td><input class="form-control" type="text" name="email" /></td>
		</tr>

		<tr>
			<td>Password:</td>
			<td><input class="form-control" type="password" name="password" /></td>
		</tr>
		<tr>
			<td>Confirm Password:</td>
			<td><input class="form-control" type="password" name="password2" /></td>
		</tr>

		<tr>
			<td>First Name:</td>
			<td><input class="form-control" type="text" name="firstName" /></td>
		</tr>
		<tr>
			<td>Last Name:</td>
			<td><input class="form-control" type="text" name="lastName" /></td>
		</tr>
		<tr>
		</tr>

		<tr>
		
			<td colspan="2" align="center">			<br>
			<input type="submit" value="Submit" />
			</td>
		</tr>

	</table>
</form>

	Already registered? <a href="{{route('login')}}">Login Here</a>

@endsection
</div>
</div>
</div>
</div>
</div>
</div>
</html>