@extends('layouts.app')
<html>

<h2>Login Failed</h2>
<table>
	<tr>
		<td>Login Error:</td>
		<td>{{ $msg }}</td>
	</tr>

	<tr>
		<td><a href="{{route('login')}}">Login Here</a></td>
	</tr>
</table>

</html>