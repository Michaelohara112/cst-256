@extends('layouts.app')
<html>

<h2>Login Success</h2>
<table>
	<tr>
		<td>Successfully logged in as:</td>
		<td>{{ $email }}</td>
	</tr>

	<tr>
		<td><a href="{{route('register')}}">Register Here</a></td>
	</tr>

</table>
</html>