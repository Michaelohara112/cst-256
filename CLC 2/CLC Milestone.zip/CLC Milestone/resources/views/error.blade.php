
<html>



@extends('layouts.app')
@section('title', 'Home')
@section('content')


    
    
				<div class="content-container">
				<h1>Error: </h1>
				<div class="error">{{ $error }}</div>
				</div>
		

@endsection

</html>