<?php

namespace App\Services\Business;

use App\models\CarModel;

class SecurityService
{
    public function login($car)
    {
        $car = new CarModel($make, $model, $year, $color);
        //set variables
        $make = $car->getMake();
        $model = $car->getModel();
        $year = $car->getYear();
        $color = $car->getColor();
        
        //set variables
        $car->setMake($make);
        $car->setModel($model);
        $car->setYear($year);
        $car->setColor($color);
        
        //checks if any of the values are equal to the values
        if('CST-256'== $make && 'CST-256'== $model && 'CST-256'== $year && 'CST-256'== $color)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}