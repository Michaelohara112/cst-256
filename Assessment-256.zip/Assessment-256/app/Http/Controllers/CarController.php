<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;
use App\Models\CarModel;
use App\Services\Business\SecurityService;

class CarController extends BaseController
{
    public function index(Request $request)
    {
        
        $make = $request->input('make');
        $model = $request->input('model');
        $year = $request->input('year');
        $color = $request->input('color');
        
        
        $securityService = new SecurityService($request);
        
        //Returns the view
        return $securityService->login($request );
    }
}
