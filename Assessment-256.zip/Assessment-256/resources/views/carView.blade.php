@section('content')
<html>
	<h2>Car Information</h2>

	
	<h2>{{ $car->$getMake() }}</h2>
	
</html>