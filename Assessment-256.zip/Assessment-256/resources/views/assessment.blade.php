<html>

    <head>
    	<title>Cars Page</title>
    </head>
    <body>
    	<div>
    		<form action="doCar" method="post">
    			{{ csrf_field() }}
    			<div class="demo-table">
    				<div class="form-head">Add Car</div>
    				<div class="field-column">
    					<div>
    						<label for="model">Model</label><span id="model_info" class="error-info"></span>
    					</div>
    					<div>
    						<input name="model" id="model" type="text" class="demo-input-box">
    					</div>
    				</div>
    				<div class="field-column">
    					<div>
    						<label for="make">Make</label><span id="make_info" class="error-info"></span>
    					</div>
    					<div>
    						<input name="make" id="make" type="text" class="demo-input-box">
    					</div>
    				</div>
    				<div class="field-column">
    					<div>
    						<label for="year">Year</label><span id="year_info" class="error-info"></span>
    					</div>
    					<div>
    						<input name="Year" id="Year" type="text" class="demo-input-box">
    					</div>
    				</div>
    				<div class="field-column">
    					<div>
    						<label for="color">Color</label><span id="color_info" class="error-info"></span>
    					</div>
    					<div>
    						<input name="color" id="color" type="text" class="demo-input-box">
    					</div>
    				</div>
    			</div>
    			<div class="field-column">
    				<input type="submit" class="btnCar">
    			</div>
    		</form>
    	</div>
    </body>
</html>