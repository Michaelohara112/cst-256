<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Services\Business\SecurityService;

class LoginController extends Controller
{
    //To obtain an instance of the current http request from a post
    public function index(Request $request)
    {
        $credentials = new UserModel($request->get('user_name'), $request->get('password'));
        $serviceLogin = new SecurityService();
        $isValid = $serviceLogin->login($credentials);
        if($isValid)
        {
            return view('loginPassed2');
        }
        else 
        {
            return view('loginFailed');
        }
        
        
        
//         $formValues = $request->all();
//         $username = $request->get('user_name');
//         return $request->all();
    }
}
