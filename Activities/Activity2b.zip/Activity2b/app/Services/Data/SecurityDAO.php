<?php
namespace App\Services\Data;
use App\Models\UserModel;
use Carbon\Exceptions\Exception;

class SecurityDAO
{
    //Define connection string
    private $conn;
    private $servername = "localhost";
    private $username = "root";
    private $password = "root";
    private $dbname = "activity2";
    private $dbquery;
    
    //constructor that creates conn with database
    public function __construct()
    {
        $this->conn = mysqli_connect($this->servername, $this->username, $this->password, $this->dbname);
    }
    
    public function findByUser(UserModel $credentials)
    {
        try 
        {
            $this->dbquery ="SELECT Username, Password FROM user 
                             WHERE Username = '{$credentials->getUsername()}' 
                                AND Password = '{$credentials->getPassword()}'";
            $result = mysqli_query($this->conn, $this->dbquery);
            if (mysqli_num_rows($result) > 0)
            {
                return true;
            }
            else 
            {
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return false;
            }
        } 
        catch (Exception $e)
        {
            echo $e->getMessage();
        }
    }
}