@extends('layouts.appmaster')
@section('title', 'ICA Page')

@section('content')

@endsection('content')
