<footer style='width:100%;display:flex;justify-content:center;'>
	<h5>Copyright @ 2021 Cender Design</h5>
</footer>
