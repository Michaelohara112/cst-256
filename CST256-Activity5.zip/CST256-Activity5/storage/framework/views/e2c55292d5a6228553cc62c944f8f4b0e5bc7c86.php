<footer style='width:100%;display:flex;justify-content:center;'>
	<h5>Copyright @ 2021 Cender Design</h5>
</footer>
<?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CST256-Activity5\resources\views/layouts/footer.blade.php ENDPATH**/ ?>