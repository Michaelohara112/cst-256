<html>




<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>


    
    
    
    	<?php if(session('user')): ?>

			

			<div class="content-container">
				<h1>Welcome</h1>
			         <div class="content-element-center">
    					Navigate through the website using the links in the top right
    				</div>
			

			</div>
				
		<?php else: ?>
			
			
			<div class="left">
			
				<h1>Welcome</h1>
				
				<div>
					Test
				</div>
			
				
			</div>
			<div class="right">
			
				<h1>Create Account</h1>
                <?php echo $__env->make('user.register.register-form-module', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				
			</div>
			
		
		<?php endif; ?>

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone2\resources\views/home.blade.php ENDPATH**/ ?>