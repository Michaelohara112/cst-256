
<html>



<div class="login-form-small">
    <form action="doLogin" method="POST">
    	<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
    	<table>
    		<tr>
    			<td>
    				Email Address<br>
    				<input type="text" name="email" /><br>
    				
    			</td>
    			<td>
    				Password<br>
    				<input type="password" name="password" />
    			</td>
    			<td>
    			<br>
    				<input type="submit" value="Login" />
    			</td>
    		</tr>
            <tr>
            	<td> 
            		<a href="<?php echo e(route('register')); ?>">Register Here</a>
            	</td>
            </tr>
    	</table>
    </form>
</div>


</html><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone2\resources\views/user/login/login-form-small.blade.php ENDPATH**/ ?>