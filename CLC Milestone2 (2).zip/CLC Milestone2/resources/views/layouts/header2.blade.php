<html>
	<h2><div align="center">Welcome to Activity 6</div>
	</h2>
	

</html>