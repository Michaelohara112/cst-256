
<html>

<h2>Register Failed</h2>
<table>
	<tr>
		<td>Register Error:</td>
		<td>{{ $msg }}</td>
	</tr>

	<tr>
		<td><a href="{{route('register')}}">Register Here</a></td>
	</tr>
</table>

	</html>