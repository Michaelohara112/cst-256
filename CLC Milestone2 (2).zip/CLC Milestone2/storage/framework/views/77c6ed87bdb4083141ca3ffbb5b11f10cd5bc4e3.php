<html lang="en">
    <head>
    	<link href="https://fonts.googleapis.com/css?family=Raleway:100,600"
        	rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet" type="text/css">
        
       <link href="<?php echo e(URL::asset('public/css/style.css')); ?>?<?php echo time(); ?>" rel="stylesheet">
          <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
          <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    
    	<title><?php echo $__env->yieldContent('title'); ?></title>
    	
    	
    </head>
    <body>
    	<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    	
    	<div class="content">
    		<div align="center"><?php echo $__env->yieldContent('content'); ?></div>
    	</div>
    	
    	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH C:\Users\Michael O'Hara\Php Workspace\W3T2Authentication2\resources\views/layouts/appmaster.blade.php ENDPATH**/ ?>