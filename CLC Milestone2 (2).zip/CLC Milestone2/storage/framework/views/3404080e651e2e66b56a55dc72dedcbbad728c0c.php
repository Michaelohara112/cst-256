<html>




<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>


    <div class="my-profile">
    <div class="content-container">
    	<h1>Profile</h1>
        	<?php if(isset($operation)): ?>
    			<div class="operation">
    				<?php echo e($operation); ?>

    			</div>
    			<br>
    	<?php endif; ?>
    	<table>

    		<tr>
    			<td><b>Email: </b></td> 
    			<td><?php echo e($user->getEmail()); ?></td> 
    		</tr>
    		<tr>
    			<td><b>Password: </b></td> 
    			<td><?php echo e($user->getPassword()); ?></td> 
    		</tr>
    		<tr>
    			<td><b>First Name: </b></td> 
    			<td><?php echo e($user->getFirstName()); ?></td> 
    		</tr>
    		
    		<tr>
    			<td><b>Last Name: </b></td> 
    			<td><?php echo e($user->getLastName()); ?></td> 
    		</tr>
    		
    		<tr>
    			<td><b>Permissions: </b></td> 
    			<td><?php echo e($user->getRights()); ?></td> 
    		</tr>
    		<tr>
    			<td><b>Role: </b></td> 
    			<td><?php echo e($user->getRole()); ?></td> 
    		</tr>
    		<tr>
    			<td><b>Objectives: </b></td> 
    			<td><textarea readonly><?php echo e($user->getObjective()); ?></textarea></td> 
    		</tr>
    		<tr>
    			<td><b>Education: </b></td> 
    			<td><textarea readonly><?php echo e($user->getEducation()); ?></textarea></td> 
    		</tr>
    		<tr>
    			<td><b>Skills: </b></td> 
    			<td><textarea readonly><?php echo e($user->getSkills()); ?></textarea></td> 
    		</tr>
    		<tr>
    		<td><b>References: </b></td> 
    			<td><textarea readonly><?php echo e($user->getReferences()); ?></textarea></td> 
    		</tr>
    		
    		
    	</table>
    	<td>Edit Profile <a href="<?php echo e(route('editProfile')); ?>">here</a></td> 
    		
    		
    </div>
    </div>
    

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone - Copy\resources\views/user/profile/my-profile.blade.php ENDPATH**/ ?>