<html>



<?php $__env->startSection('title', 'Login Page'); ?>
<?php $__env->startSection('content'); ?>


<div class="content-container">

<form action="doLogin" method="POST">
	<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
	<h2>Login</h2>
	<?php if(isset($error)): ?>
		<div style="color: red">
    		Error: <?php echo e($error); ?> <br>
    		<br>
    	</div>
    <?php endif; ?>	
    

    
	<table>
		<tr>
			<td>Email Address:</td>
			<td><input type="text" name="email" /></td>
		</tr>

		<tr>
			<td>Password:</td>
			<td><input type="password" name="password" /></td>
		</tr>

		<tr>
			<br>
			<td colspan="2" align="center"><input type="submit" value="Login" />
			</td>
		</tr>
	</table>
</form>

	Not Registered? <a href="<?php echo e(route('register')); ?>">Create Account Here</a>


<?php $__env->stopSection(); ?>

</div>
</html>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone2\resources\views/user/login/login-form.blade.php ENDPATH**/ ?>