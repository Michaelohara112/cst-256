<html>




    		<h5><div align="center">Copyright @2017 My Own Company Name</div></h5>


</html>