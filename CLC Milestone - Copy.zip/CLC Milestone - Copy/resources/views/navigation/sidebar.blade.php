
<div class="left-sidebar">
	<h3>Menu</h3>
	<ul>
		<li><a href="{{route('home')}}">Home</a></li>
		<li><a href="{{route('home')}}">Edit Profile</a></li>
		<li><a href="{{route('home')}}">Admin Panel</a></li>
		
		
		
		
		<!--  <img src="{{ asset('public/images/icons/home.png') }}" style='vertical-align:middle;' width="38" height="38"> -->
		
		
	</ul>


</div>