<html>




<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>


    
    
    
    	<?php if(session('user')): ?>

			

			<div class="content-container">
				<h1>Feed</h1>
			      <?php for($i =0; $i <= 100; $i++): ?>
                    <div class="content-element-center">
    					center element <?php echo e($i); ?>

    				</div>
                  <?php endfor; ?>  
			

			</div>
				
		<?php else: ?>
			
			
			<div class="left">
			
				<h1>Welcome</h1>
				
				<div>
					Test
				</div>
			
				
			</div>
			<div class="right">
			
				<h1>Create Account</h1>
                <?php echo $__env->make('user.register.register-form-module', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				
			</div>
			
		
		<?php endif; ?>

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone - Copy\resources\views/home.blade.php ENDPATH**/ ?>