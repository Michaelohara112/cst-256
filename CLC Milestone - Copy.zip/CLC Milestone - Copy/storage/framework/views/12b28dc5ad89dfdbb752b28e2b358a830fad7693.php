<html>




<?php $__env->startSection('title', 'Job'); ?>
<?php $__env->startSection('content'); ?>


    <div class="my-profile">
    <div class="content-container">
    <div class="job">
    	<h1>Create Job</h1>
        	<?php if(isset($operation)): ?>
    			<div class="operation">
    				<?php echo e($operation); ?>

    			</div>
    			<br>
    		<?php endif; ?>
    		<?php if(isset($errors)): ?>
        		<div style="color: red">
                    <ul style="list-style-type: none">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
            	</div>
            <?php endif; ?>	
    	<form action="createJob" method="POST">
    	<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">	
        	<table>
    
        		<tr>
        			<td><b>Title: </b></td> 
        			<td><input type="text" name="TITLE" value="" /></td>
        		</tr>
        		<tr>
        			<td><b>Company: </b></td> 
        			<td><input type="text" name="COMPANY" value="" /></td>
        		</tr>
        		<tr>
        			<td><b>Salary: </b></td> 
        			<td><input type="text" name="SALARY" value="" /></td>
        		</tr>
        		    		
        		<tr>
        			<td><b>Location: </b></td> 
        			<td><input type="text" name="LOCATION" value="" /></td>
        		</tr>
        		<tr>
        			<td><b>Description: </b></td> 
        			<td><textarea name="DESCRIPTION" maxlength="500"></textarea></td> 
        		</tr>
    
        		<tr>
        			<td><b>Experience Required: </b></td> 
        			<td><textarea name="EXPERIENCE" maxlength="500"></textarea></td> 
        		</tr>
    
        		
        		
        	</table>
        	<input type="submit" value="Submit" />
        	
        	
    	</form>
    	<a href="<?php echo e(route('jobs')); ?>">Back</a>
    		
    	</div>	
    </div>
    </div>
    

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone - Copy\resources\views/user/jobs/new-job.blade.php ENDPATH**/ ?>