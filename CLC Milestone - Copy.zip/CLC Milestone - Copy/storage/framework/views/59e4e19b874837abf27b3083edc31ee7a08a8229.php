<?php $__env->startSection('title', 'Register Page'); ?>
<?php $__env->startSection('content'); ?>

<html>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
<form action="doRegister" method="POST">
	<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
		<?php if(isset($error)): ?>
    		<div style="color: red">
        		Error: <?php echo e($error); ?> <br>
        		<br>
        	</div>
    	<?php endif; ?>	
	<table>
		<tr>
			<td>Email Address:</td>
			<td><input class="form-control" type="text" name="email" /></td>
		</tr>

		<tr>
			<td>Password:</td>
			<td><input class="form-control" type="password" name="password" /></td>
		</tr>
		<tr>
			<td>Confirm Password:</td>
			<td><input class="form-control" type="password" name="password2" /></td>
		</tr>

		<tr>
			<td>First Name:</td>
			<td><input class="form-control" type="text" name="firstName" /></td>
		</tr>
		<tr>
			<td>Last Name:</td>
			<td><input class="form-control" type="text" name="lastName" /></td>
		</tr>
		<tr>
		</tr>

		<tr>
		
			<td colspan="2" align="center">			<br>
			<input type="submit" value="Submit" />
			</td>
		</tr>

	</table>
</form>

	Already registered? <a href="<?php echo e(route('login')); ?>">Login Here</a>

<?php $__env->stopSection(); ?>
</div>
</div>
</div>
</div>
</div>
</div>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\W3T2Authentication2\resources\views/user/register/register-form.blade.php ENDPATH**/ ?>