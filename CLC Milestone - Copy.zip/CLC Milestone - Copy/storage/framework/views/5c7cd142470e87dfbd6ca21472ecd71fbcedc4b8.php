<html>




<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>


    
    <div class="content-container">
    <div class="admin-panel">
    		<h1>Admin Panel</h1>
    		<div>Edit data for user: <?php echo e($user->EMAIL); ?></div>
    		<br>
    		<?php if(isset($operation)): ?>
    			<div class="operation">
    				<?php echo e($operation); ?>

    			</div>
    			<br>
    		<?php endif; ?>
    		
				
    		<form action="adminSave" method="POST" style="display: inline;">
            	<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
            	<input type="hidden" name="id" value="<?php echo $user->ID ?>">
      	
        		<table>
        			
        			<th>
        				ID
        			</th>
        			<th>
        				Email Address
        			</th>
        			<th>
        				Password
        			</th>
        			<th>
        				First Name
        			</th>
        			<th>
        				Last Name
        			</th>
        			<th>
        				Rights
        			</th>
        			<th>
        				Operation
        			</th>
    
    				
        			<tr>
        			    <td>	
                        	<?php echo e($user->ID); ?>

                        	<input type="hidden" name="ID" value="<?php echo e($user->ID); ?>" />
                        </td>
            			<td>	
            				<input type="text" name="EMAIL" value="<?php echo e($user->EMAIL); ?>" />
                        </td>
            			<td>	
            				<input type="text" name="PASSWORD" value="<?php echo e($user->PASSWORD); ?>" />
                        </td>
            			<td>	
            				<input type="text" style= "width: 120px;" name="FIRSTNAME" value="<?php echo e($user->FIRSTNAME); ?>" />
                        </td> 
            			<td>	
                        	<input type="text" style= "width: 120px;" name="LASTNAME" value="<?php echo e($user->LASTNAME); ?>" />
                        </td>
            			<td>	
                        	<input type="text" style= "width: 20px;" name="RIGHTS" value="<?php echo e($user->RIGHTS); ?>" />
                        </td>
                        <td>
 
                        	<input type ="image" src="<?php echo e(asset('public/images/icons/save.png')); ?>" title="Save" style="vertical-align:middle; display:inline;" width="24" height="24"> 
                   
                        </td>
                    </tr>
    
                </table>
                <br>
                <div><a href="<?php echo e(route('admin')); ?>">Back to admin panel</a></div>
            </form>
     	</div>
    </div>
    

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\W3T2Authentication2\resources\views/user/admin/edit-user.blade.php ENDPATH**/ ?>