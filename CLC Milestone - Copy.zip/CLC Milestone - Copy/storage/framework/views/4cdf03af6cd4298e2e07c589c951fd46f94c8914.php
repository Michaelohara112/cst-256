
<html>




   <nav>
        <ul>
            <li>
            	
            	
            	<a href="<?php echo e(route('myProfile')); ?>">My Profile</a>
            </li>
            
            <?php if(session('user')->getRights() > 0): ?> 
             <li>
            	<a href="<?php echo e(route('admin')); ?>">Admin</a>
            
             </li>
            <?php endif; ?>
             <li>
            	<a href="<?php echo e(route('jobs')); ?>">Jobs</a>
            
             </li>
            <li>
            	<a href="<?php echo e(route('home')); ?>">Home</a>
            </li>
            

            <li>
            	<a href="<?php echo e(route('logout')); ?>">Sign Out</a>
            </li>
       </ul>
        
    </nav>





</html><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone - Copy\resources\views/navigation/nav-bar.blade.php ENDPATH**/ ?>