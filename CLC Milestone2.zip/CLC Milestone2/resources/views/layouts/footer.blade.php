<html>

	<div class="footer">


    		<h5>Copyright @2017 My Own Company Name</h5>

    </div>
</html>