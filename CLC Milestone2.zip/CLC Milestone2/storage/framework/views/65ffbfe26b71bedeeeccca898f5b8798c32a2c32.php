
<html>

<h2>Register Success</h2>
<table>
	<tr>
		<td>Successfully registered as:</td>
		<td><?php echo e($email); ?></td>
	</tr>

	<tr>
		<td><a href="<?php echo e(route('login')); ?>">Login Here</a></td>
	</tr>

</table>

</html><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone\resources\views/user/register/registerPassed.blade.php ENDPATH**/ ?>