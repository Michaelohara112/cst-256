<html>




<?php $__env->startSection('title', 'groups'); ?>
<?php $__env->startSection('content'); ?>


    <div class="my-profile">
    <div class="content-container">
    <div class="job">
    	<h1>Edit Group</h1>
        	<?php if(isset($operation)): ?>
    			<div class="operation">
    				<?php echo e($operation); ?>

    			</div>
    			<br>
    		<?php endif; ?>
    		<?php if(isset($errors)): ?>
        		<div style="color: red">
                    <ul style="list-style-type: none">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
            	</div>
            <?php endif; ?>	
        	<table>
        		<form id="update" action="updateGroup" method="POST">
                	<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">	
                	
                	<input type="hidden" name ="ID" value="<?php echo e($group->getId()); ?>">
            		<tr>
            			<td><b>Title: </b></td> 
            			<td><input type="text" name="TITLE" value="<?php echo e($group->getTitle()); ?>" /></td>
            		</tr>   		
            		<tr>
            			<td><b>Description: </b></td> 
            			<td><textarea name="DESCRIPTION" maxlength="500"><?php echo e($group->getDescription()); ?></textarea></td> 
            		</tr>        		
            		
        		</form>
            		<tr>

            			<td><b>Members (<?php echo e($group->getMembers()); ?>): </b></td> 
            			<td>
            				<?php $__currentLoopData = $group->getUsers(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            				
            					<?php echo e($member->getFirstName()); ?> <?php echo e($member->getLastName()); ?> (<?php echo e($member->getEmail()); ?>): 
            					[<form action="removeFromGroup" method="POST" style="display: inline;" onSubmit="if(!confirm('Are you sure?')){return false;}">
                                		<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">	
                                		<input type="hidden" name ="USER_ID" value="<?php echo e($member->getId()); ?>">
                                		<input type="hidden" name ="GROUP_ID" value="<?php echo e($group->getId()); ?>">
                                		<a href="#" onclick="this.parentNode.submit();">Remove</a>
                                		
                                	</form>], 
            				
            				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            			
        				</td>  
        			</tr>
    
        		
        		
        	</table>
        	<input form="update" type="submit" value="Save" />

    	
    	<a href="<?php echo e(route('groups')); ?>">Back</a>
    		
    	</div>	
    </div>
    </div>
    

<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael O'Hara\Php Workspace\CLC Milestone\resources\views/user/groups/edit-group.blade.php ENDPATH**/ ?>